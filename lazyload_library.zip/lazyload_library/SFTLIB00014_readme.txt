Image Lazy Load on Scroll  with sample :-

Steps for installation :-
Unzip files and save into your local server - htdocs/ or www/

Description :-
Image Lazy Load on Scroll and increase your web-performance

Folder Structure :-

Bugs & Errors :-

Features :-
Image Lazy Load on Scroll

Plateform :-
php

Advantage :-
After useing lazyload it will increase web-performance

Disadvantage :-

